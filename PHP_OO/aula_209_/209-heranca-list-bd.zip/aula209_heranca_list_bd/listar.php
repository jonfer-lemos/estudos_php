<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require './Conn.php';
        require './ListContact.php';
        
        $listMsgContact = new ListContact();
        $result_list_contacts = $listMsgContact->list();
        foreach ($result_list_contacts as $row_list_contact) {
            extract($row_list_contact);
            echo "ID: " . $id . "<br>";
            echo "Nome: " . $name . "<br>";
            echo "E-mail: " . $email . "<br>";
            echo "Titulo: " . $msg_title . "<br>";
            echo "Conteúdo: " . $msg_content . "<br>";
            echo "<hr>";
        }
        ?>
    </body>
</html>
