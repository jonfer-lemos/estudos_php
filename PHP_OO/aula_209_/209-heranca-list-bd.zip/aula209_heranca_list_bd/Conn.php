<?php

/**
 * Description of Conn
 *
 * @author Cesar Szpak <cesar@celke.com.br>
 * @copyright (c) year, Celke
 */
abstract class Conn
{
    public string $db = "mysql";
    public string $host = "localhost";
    public string $user = "root";
    public string $pass = "";
    public string $dbname = "celke";
    public int $port = 3308;
    public object $connect;
    
    public function connect() {
        try{
            $this->connect = new PDO($this->db. ':host='. $this->host . ';port=' . $this->port . ';dbname=' .$this->dbname, $this->user, $this->pass);
            return $this->connect;
        } catch (Exception $ex) {
            die('Erro: Por favor tente novamente. Caso o problema persista, entre em contato o administrador adm@empresa.com');
        }
    }
}
